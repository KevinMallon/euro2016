class TeamsController < ApplicationController
  def index
    @teams = Team.all;
    @users = User.all;
    @team_icons = TeamIcon.all
    @teams_picked = Team.where("user_id is NOT NULL and name != ''")
    @draft_order = User.all.sort_by { |a| a[:draft_position] }
    @minimum_teams_needed = 8
  end
  
  def new
    @team = Team.new
    respond_to do |format|

      format.html # new.html.erb
      format.json { render json: @team }
    end
  end

  # GET /teams/1/edit

  def edit
      @team = Team.find(params[:id])
        respond_to do |format|
        format.html 
        format.js 
      end
  end
  
# PUT /teams/1
# PUT /teams/1.json
  def update
    @team = Team.find(params[:id])
    
    respond_to do |format|

      if @team.update_attributes(params.require(:team).permit(:name, :group, :owner, :roundof16, :roundof8, :roundof4, :roundof2, :champion, :user_id))
        format.html { redirect_to teams_index_path, notice: 'team updated.' }
        format.js { head :no_content }
      else
        format.html { render action: "edit" }
        format.json { render json: @team.errors, status: :unprocessable_entity, notice: 'Unable to update team.' }
      end
  end

  end

end
