class TeamIconsController < ApplicationController
  before_action :set_team_icon, only: [:show]

  # GET /users
  # GET /users.json
  def index
    @team_icons = TeamIcon.all
    @teams = Team.all
  end

  # GET /users/1
  # GET /users/1.json
  def show
    @team_icon = TeamIcon.find(params[:id])
    @teams = Team.all
  end
    
      private
    # Use callbacks to share common setup or constraints between actions.
    def set_team_icon
      @team_icons = TeamIcon.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def team_icon_params
      params.require(:id).permit(:icon, :team_id)
    end
end
