class StaticPagesController < ApplicationController
  def home
  end

  def draft
  @users = User.all
  @teams = Team.all
  @team = current_user.teams.build if logged_in?  
  end
end
