class PoolsController < ApplicationController
end
