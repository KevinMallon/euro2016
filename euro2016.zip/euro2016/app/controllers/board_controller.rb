class BoardController < ApplicationController
  def home
    @teams = Team.all
  end


  
  # def select_all()
  #   @teams = Team.all
  # end
  
  def admin
    @teams = Team.all
  end
end
