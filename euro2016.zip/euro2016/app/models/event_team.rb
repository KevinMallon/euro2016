class EventTeam < ActiveRecord::Base
    has_many :events
    has_many :teams
end
