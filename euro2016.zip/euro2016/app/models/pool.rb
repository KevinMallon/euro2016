class Pool < ActiveRecord::Base
    belongs_to :event
    
end
