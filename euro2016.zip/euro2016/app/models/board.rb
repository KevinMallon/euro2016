class Board < ActiveRecord::Base
    
      
  def owner_points
    owner_points = 0
    jamie_teams = Team.where(owner: "Jamie")
      jamie_teams each do |team|
        owner_points = owner_points += team.team_points
      end
  owner_points
  end
      
     
      
# 	    select_all(" Select team.roundof16, team.roundof8, team.roundof4, team.roundof2, team.champion
	    
# 		l.location_name AS Requesting,
# 		SUM(e.location_id = 1) AS Chicago,
# 		SUM(e.location_id = 2) AS Boston,
# 		SUM(e.location_id = 3) AS Houston,
# 		SUM(e.location_id = 4) AS San_Francisco,
# 		SUM(e.location_id = 5) AS London,
# 		SUM(e.location_id = 6) AS Mumbai
# 	FROM Requests r
# 	JOIN Selections s ON r.id = s.request_id
# 	JOIN Employees e ON e.id = s.employee_id
# 	JOIN Locations l ON l.id = r.location_id
# 	WHERE julianday(r.start_date)>= julianday('now','-6 months') AND r.location_id != e.location_id
# 	GROUP BY Requesting " )
  
  
end
