class Team < ActiveRecord::Base
 
  belongs_to :user
  has_one :team_icon
  has_many :events, :through => :event_teams
  has_many :event_teams

  
  def select_all(query)  	
  	ActiveRecord::Base.connection.select_all(query)  
  end 	
  
  def user_teams
    Team.where("user_id = ?", id)
  end
  
  def user_points
        select_all( " SELECT name FROM Teams WHERE owner = 'Jamie' " )
      select_all(Team.where(owner: "Jamie"))
      (" Select SUM(roundof16, roundof8, roundof4, roundof2, champion) AS sum_points
      WHERE owner = 'Jamie' "
      )
  end    

  def calc_team_points(team)
    rd16teampts = 0
    rd8teampts = 0
    rd4teampts = 0
    rd2teampts = 0
    championteampts = 0
    team_points = 0
    if team.roundof16.blank? 
      rd16teampts = 0    
    elsif team.roundof16 == "W" 
      rd16teampts = 3
    end

    if team.roundof8.blank? 
      rd8teampts = 0     
    elsif team.roundof8 == "W" 
      rd8teampts = 6
    elsif team.roundof8 == "SOW"
      rd8teampts = 5
    elsif team.roundof8 == "SOL"
      rd8teampts = 1
    end    

    if team.roundof4.blank? 
      rd4teampts = 0     
    elsif team.roundof4 == "W" 
      rd4teampts = 6
    elsif team.roundof4 == "SOW"
      rd4teampts = 5
    elsif team.roundof4 == "SOL"
      rd4teampts = 1
    end        

    if team.roundof2.blank? 
      rd2teampts = 0        
    elsif team.roundof2 == "W" 
      rd2teampts = 6
    elsif team.roundof2 == "SOW"
      rd2teampts = 5
    elsif team.roundof2 == "SOL"
      rd2teampts = 1
    end   
    
    if team.champion.blank? 
      championteampts = 0        
    elsif team.champion == "W" 
      championteampts = 9
    elsif team.champion == "SOW"
      championteampts = 8
    elsif team.champion == "SOL"
      championteampts = 1
    end   
    team_points = rd16teampts + rd8teampts + rd4teampts + rd2teampts + championteampts
    team_points
  end
  
end
