class TeamIcon < ActiveRecord::Base
    
      belongs_to :team
end
