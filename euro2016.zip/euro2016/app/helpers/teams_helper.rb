module TeamsHelper
  def whos_on_clock(current_pick, draft_order)
    case current_pick
        when 1, 12, 13, 24 then draft_order[0]
        when 2, 11, 14, 23 then draft_order[1]
        when 3, 10, 15, 22 then draft_order[2]
        when 4, 9, 16, 21  then draft_order[3]
        when 5, 8, 17, 20  then draft_order[4]
        else               draft_order[5]
    end
  end
end
