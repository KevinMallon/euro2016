module TeamIconsHelper
end
