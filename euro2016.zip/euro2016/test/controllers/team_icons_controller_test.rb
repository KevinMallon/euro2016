require 'test_helper'

class TeamIconsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
