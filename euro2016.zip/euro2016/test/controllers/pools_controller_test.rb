require 'test_helper'

class PoolsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
