class CreateTeamIcons < ActiveRecord::Migration
  def change
    create_table :team_icons do |t|
      t.string :icon
      t.integer :team_id

      t.timestamps null: false
    end
  end
end
