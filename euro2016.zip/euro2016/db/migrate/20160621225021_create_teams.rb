class CreateTeams < ActiveRecord::Migration
  def change
    create_table :teams do |t|
      t.string :name, null: false
      t.string :group, null: false
      t.string :owner, null: false
      t.string :roundof16, null: false
      t.string :roundof8, null: false
      t.string :roundof4, null: false
      t.string :roundof2, null: false
      t.string :champion, null: false

      t.timestamps null: false
    end
  end
end
