class AddDraftpositionToUsers < ActiveRecord::Migration
  def change
    add_column :users, :draftposition, :real
  end
end