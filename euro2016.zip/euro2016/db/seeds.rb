# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#

test_users = [
  [ "Lee", "lee@test.com"],
  [ "Kevin", "kevin@test.com"],
  [ "Jake", "jake@test.com"],
  [ "Josh", "josh@test.com"],
  [ "John", "john@test.com"],
  [ "Alice", "alice@test.com"],
  [ "Sunny", "sunny@test.com"],
  [ "Fabio", "fabio@test.com"]
]

puts("Creating Test Users")
test_users.each do |name, email|
  User.create(name: name, email: email)
end

team_list = [
  [ "France", "A", "Jamie", 0, 0, 0, 0, 0 ],
  [ "Switzerland", "A", "Robert", 0, 0, 0, 0, 0 ],
  [ "Romania", "A", "Mark", 0, 0, 0, 0, 0 ],
  [ "Albania", "A", "Jeff", 0, 0, 0, 0, 0 ],
  [ "England", "B", "Jeff", 0, 0, 0, 0, 0 ],
  [ "Wales", "B", "Jamie", 0, 0, 0, 0, 0 ],
  [ "Slovakia", "B", "Kevin", 0, 0, 0, 0, 0 ],
  [ "Russia", "B", "Jamie", 0, 0, 0, 0, 0 ],
  [ "Germany", "C", "Mark", 0, 0, 0, 0, 0 ],
  [ "Poland", "C", "Mark", 0, 0, 0, 0, 0 ],
  [ "Ukraine", "C", "Kevin", 0, 0, 0, 0, 0 ],
  [ "N. Ireland", "C", "Jamie", 0, 0, 0, 0, 0 ],
  [ "Belgium", "D", "Andy", 0, 0, 0, 0, 0 ],
  [ "Italy", "D", "Mark", 0, 0, 0, 0, 0 ],
  [ "Rep. of Ireland", "D", "Andy", 0, 0, 0, 0, 0 ],
  [ "Sweden", "D", "Robert", 0, 0, 0, 0, 0 ],
  [ "Spain", "E", "Kevin", 0, 0, 0, 0, 0 ],
  [ "Czech Republic", "E", "Andy", 0, 0, 0, 0, 0 ],
  [ "Croatia", "E", "Andy", 0, 0, 0, 0, 0 ],
  [ "Turkey", "E", "Robert", 0, 0, 0, 0, 0 ],
  [ "Portugal", "F", "Robert", 0, 0, 0, 0, 0 ],
  [ "Austria", "F", "Kevin", 0, 0, 0, 0, 0 ],
  [ "Hungary", "F", "Andy", 0, 0, 0, 0, 0 ],
  [ "Iceland", "F", "Jeff", 0, 0, 0, 0, 0 ]
]

puts("Creating Teams")
team_list.each do |name, group, owner, roundof16, roundof8, roundof4, roundof2, champion|
  Team.create( name: name, group: group, owner: owner, roundof16: roundof16, roundof8: roundof8, roundof4: roundof4, roundof2: roundof2, champion: champion)
end


team_icon_path = [
  [ "France.png", 1 ],
  [ "Switzerland.png", 2 ],
  [ "Romania.png", 3 ],
  [ "Albania.png", 4 ],
  [ "England.png", 5 ],
  [ "Wales.png", 6 ],
  [ "Slovakia.png", 7 ],
  [ "Russia.png", 8 ],
  [ "Germany.png", 9 ],
  [ "Poland.png", 10 ],
  [ "Ukraine.png", 11 ],
  [ "Northernireland.png", 12 ],
  [ "Belgium.png", 13 ],
  [ "Italy.png", 14 ],
  [ "Ireland.png", 15 ],
  [ "Sweden.png", 16 ],
  [ "Spain.png", 17 ],
  [ "Czechrepublic.png", 18 ],
  [ "Croatia.png", 19 ],
  [ "Turkey.png", 20 ],
  [ "Portugal.png", 21 ],
  [ "Austria.png", 22 ],
  [ "Hungary.png", 23 ],
  [ "Iceland.png", 24 ]
]

puts("Creating Team Icons")
team_icon_path.each do |icon, team_id|
  TeamIcon.create( icon: icon, team_id: team_id )
end

puts("Finished Seedings Data")